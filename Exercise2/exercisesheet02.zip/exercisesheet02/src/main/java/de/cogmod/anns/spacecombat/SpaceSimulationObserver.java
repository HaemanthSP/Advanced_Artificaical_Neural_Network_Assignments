package de.cogmod.anns.spacecombat;


/**
 * @author Sebastian Otte
 */
public interface SpaceSimulationObserver {
	
    public void simulationStep(final SpaceSimulation sim);
   
}